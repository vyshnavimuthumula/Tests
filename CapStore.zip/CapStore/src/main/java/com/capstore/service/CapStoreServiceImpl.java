package com.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.CapStore;
import com.capstore.dao.CapStoreDao;
import com.capstore.exception.CapStoreException;


@Service
public class CapStoreServiceImpl implements CapStoreService{

	@Autowired
	CapStoreDao capStoreDao;
	@Override
	public List<CapStore> addCapStore(CapStore products) throws CapStoreException {
		try {
			capStoreDao.save(products);
			return capStoreDao.findAll();
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	//MAIN THINGS

		@Override
		public List<CapStore> getAllProductDetails(String ordStatus,String ordst) throws CapStoreException {
			try {
				if((ordStatus.equals("PLD")|| ordst.equals("DISP"))||(ordStatus.equals("DISP")|| ordst.equals("PLD"))) {
					return capStoreDao.getAllProductDetails(ordStatus,ordst);
				}
				else
					return capStoreDao.getAllProductDetails(ordStatus,ordst);
			}catch(Exception e) {
				throw new CapStoreException(e.getMessage());
			}
		}

	//TESTING
//	@Override
//	public List<CapStore> getAllProducts(String ordStatus) throws CapStoreException {
//		try {
//			if((ordStatus.equalsIgnoreCase("PLD")||ordStatus.equalsIgnoreCase("DISP"))&&(ordStatus.equalsIgnoreCase("DISP")||ordStatus.equalsIgnoreCase("PLD")))
//				return capStoreDao.getAllProducts(ordStatus);
//			else
//				return capStoreDao.getPlacedProducts(ordStatus);
//		}catch(Exception e) {
//			throw new CapStoreException(e.getMessage());
//		}
//	}

	@Override
	public List<CapStore> getPlacedProducts(String ordStatus) throws CapStoreException {
		try {
			if(ordStatus.equalsIgnoreCase("PLD"))
				return capStoreDao.getPlacedProducts(ordStatus);
			else {
				throw new CapStoreException("Invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	@Override
	public List<CapStore> getDispatchedProducts(String ordStatus) throws CapStoreException {
		try {
			if(ordStatus.equalsIgnoreCase("DISP"))
			return capStoreDao.getDispatchedProducts(ordStatus);
			else {
				throw new CapStoreException("Invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	@Override
	public List<CapStore> updatePlacedProducts(String ordId, String ordStatus) throws CapStoreException {
		try {
			Optional<CapStore> optional=capStoreDao.findById(ordId);
			if(ordStatus.equalsIgnoreCase("PLD")) {
				CapStore placed=optional.get();
				placed.setOrdStatus("DISP");
				capStoreDao.save(placed);
				return capStoreDao.getPlacedProducts(ordStatus);
			}
			else {
				throw new CapStoreException("Invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
		
	}

	@Override
	public List<CapStore> updateDispatchedProducts(String ordId, String ordStatus) throws CapStoreException {
		try {
			Optional<CapStore> optional=capStoreDao.findById(ordId);
			if(ordStatus.equalsIgnoreCase("DISP")) {
				CapStore dispatched=optional.get();
				dispatched.setOrdStatus("REC");
				capStoreDao.save(dispatched);
				return capStoreDao.getPlacedProducts(ordStatus);
			}
			else {
				throw new CapStoreException("Invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	@Override
	public List<CapStore> updateProduct(String ordId, String ordStatus,String ordStatus4) throws CapStoreException {
		try {
			Optional<CapStore> optional=capStoreDao.findById(ordId);
			if(ordStatus.equalsIgnoreCase("PLD")) {
				CapStore dispatched=optional.get();
				dispatched.setOrdStatus("DISP");
				capStoreDao.save(dispatched);
				return capStoreDao.getAllProductDetails(ordStatus,ordStatus4);
			}
			else if(ordStatus.equalsIgnoreCase("DISP")) {
				CapStore dispatched=optional.get();
				dispatched.setOrdStatus("REC");
				capStoreDao.save(dispatched);
				return capStoreDao.getAllProductDetails(ordStatus,ordStatus4);
			}
			else
				throw new CapStoreException("Product is received");
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}
	
	

}
