import { CapStore } from './cap-store';

describe('CapStore', () => {
  it('should create an instance', () => {
    expect(new CapStore()).toBeTruthy();
  });
});
