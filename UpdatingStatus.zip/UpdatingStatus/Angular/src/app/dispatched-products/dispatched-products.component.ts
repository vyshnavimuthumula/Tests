import { Component, OnInit, Injectable } from '@angular/core';
import { CapStoreService } from '../cap-store.service';

@Component({
  selector: 'app-dispatched-products',
  templateUrl: './dispatched-products.component.html',
  styleUrls: ['./dispatched-products.component.css']
})
@Injectable({
  providedIn:"root"
})
export class DispatchedProductsComponent implements OnInit {
  capstore: any;

  constructor(private capStoreService:CapStoreService) { }

  ngOnInit() {
    this.capStoreService.showDispatchedProducts().subscribe(response=>this.handleSuccessfulResponse(response));
    console.log(this.capstore);
  }
  handleSuccessfulResponse(response){
    this.capstore=response;
    console.log(this.capstore);
  //   for(let i=0;i<this.capstore.length;i++){
  //     if(this.capstore[i].ordStatus==='disp'){
  //       this.capStoreService.setOrdId(this.capstore[i].ordId);
  //       console.log(this.capstore[i].ordId)
  //     }
  // }
}
    
  updateDispStatus(productOrdId: string,productOrdStatus: string){
    this.capStoreService.updateDisp(productOrdId,productOrdStatus).subscribe(data => {
      this.capstore = data;
  });
}
}

// for(let i=0;i<this.capstore.length;i++){
    //   if(this.capstore[i].ordStatus==='disp'){
    //     this.capStoreService.setOrdStatus2(this.capstore[i].ordStatus);
    //     console.log(this.capstore[i].ordStatus)
    //   }
      // else if(this.capstore[i].ordStatus=='disp')
      // this.capStoreService.setOrdStatus(this.capstore[i].ordStatus);
      // else
      //  this.capStoreService.setOrdStatus2(this.capstore[i].ordStatus);
      //console.log(this.capstore[i].ordStatus)

  //}