import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllProductsComponent } from './all-products/all-products.component';
import { PlacedProductsComponent } from './placed-products/placed-products.component';
import { DispatchedProductsComponent } from './dispatched-products/dispatched-products.component';
export const routingComponents =[AllProductsComponent,PlacedProductsComponent,DispatchedProductsComponent];

const routes: Routes = [
  {
    path:'allProducts',
    component:AllProductsComponent
  },
  {
    path:'placedProducts',
    component:PlacedProductsComponent
  },
  {
    path:'dispatchedProducts',
    component:DispatchedProductsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
