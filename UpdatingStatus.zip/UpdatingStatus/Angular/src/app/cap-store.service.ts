import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
// import { Observable } from 'rxjs';
import { OrderedItem } from './cap-store';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CapStoreService {
  ordStatus: any;
  ordId: any;
  constructor(private httpClient:HttpClient) { }

  baseUrl = "http://localhost:8081";

  getOrdStatus(){
    return this.ordStatus;
   }
   
  setOrdStatus(ordStatus:string){
    this.ordStatus=ordStatus;
   }
   getOrdStatus2(){
    return this.ordStatus;
   }
   
  setOrdStatus2(ordId:string){
    this.ordId=ordId;
   }


   //Purpose:This is for displaying all products whose status equal to placed(PLD) or dispatched(DISP)

  showAllProducts():Observable<OrderedItem[]>
  {
    
    let url = this.baseUrl + "/capstore/"+ 'PLD' + '/' + 'DISP'
    console.log(url)
    return this.httpClient.get<OrderedItem[]>(url);
  }
  getProducts():Observable<OrderedItem[]>{
    let url2 = this.baseUrl + "/capstore/"+ 'DISP' + '/' + 'PLD'
    console.log(url2)
    return this.httpClient.get<OrderedItem[]>(url2);
  }

  //Purpose:This is for Displaying all placed  products
  showPlacedProducts():Observable<OrderedItem[]>
  {
    let url = this.baseUrl + "/placedproducts";
    return this.httpClient.get<OrderedItem[]>(url);
  }

  //Purpose:This is for Displaying all dispatched products
  showDispatchedProducts():Observable<OrderedItem[]>
  {
    let url = this.baseUrl + "/dispatchedproducts"
    return this.httpClient.get<OrderedItem[]>(url);
  }

  //Purpose:This is for updating placed  product to dispatched product
  updatePld(productOrdId: string,productOrdStatus: string):Observable<OrderedItem[]>{
    let url = this.baseUrl + "/updatePlacedProducts/"+  productOrdId + '/' + productOrdStatus
    return this.httpClient.get<OrderedItem[]>(url);
  }
  
  //Purpose:This is for updating dispatched product to received product
  updateDisp(productOrdId: string,productOrdStatus: string):Observable<OrderedItem[]>{
    let url = this.baseUrl + "/updateDispatchedProducts/"+  productOrdId + '/' + productOrdStatus
    return this.httpClient.get<OrderedItem[]>(url);
  }
  updateProduct(productOrdId: string,productOrdStatus: string):Observable<OrderedItem[]>{
  
    let url = this.baseUrl + "/updateProduct/"+ productOrdId + '/' + productOrdStatus
    console.log(url)
    return this.httpClient.get<OrderedItem[]>(url);
  }
}
