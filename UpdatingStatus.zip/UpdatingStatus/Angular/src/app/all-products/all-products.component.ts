import { Component, OnInit } from '@angular/core';
import { CapStoreService } from '../cap-store.service';
import { OrderedItem } from '../cap-store';

@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.css']
})
export class AllProductsComponent implements OnInit {
  capstore: OrderedItem[];
  capstore2:OrderedItem[];

  constructor(private capStoreService:CapStoreService) { }

  ngOnInit() {
    this.capStoreService.showAllProducts().subscribe(response=>this.handleSuccessfulResponse(response));
    //this.capStoreService.getProducts().subscribe(response=>this.handleSuccessfulResponse2(response));
  }
  handleSuccessfulResponse2(response){
    this.capstore2=response;
    console.log(this.capstore2);    
    //this.capStoreService.getProducts();
    //console.log(this.capStoreService.getOrdStatus())
  }

    handleSuccessfulResponse(response){
      this.capstore=response;
     
      this.capStoreService.getProducts();
      //console.log(this.capStoreService.getOrdStatus())
  
    }
updateProduct(productOrdId: string,productOrdStatus: string){
  this.capStoreService.updateProduct(productOrdId,productOrdStatus).subscribe(data => {
    this.capstore = data;
});
}
}
