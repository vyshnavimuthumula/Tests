export class OrderedItem {
     ordId: string;
     custId: string;
     merId: string;
     ordPrice: string;
     ordQty: number;
     ordStatus: string;
     prodId: string;

    
}