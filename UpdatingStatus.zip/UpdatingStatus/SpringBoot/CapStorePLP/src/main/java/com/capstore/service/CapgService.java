package com.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.OrderedItem;
import com.capstore.dao.OrderedItemDao;
import com.capstore.exception.CapStoreException;

@Service
public class CapgService implements ICapgService{

	@Autowired 
	OrderedItemDao orderItemRepo;
	
	
	
	@Override
	public List<OrderedItem> addCapStore(OrderedItem products) throws CapStoreException {
		try {
			orderItemRepo.save(products);
			return orderItemRepo.findAll();
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}
	
	
	/***
	 * Author:Vyshnavi Muthumula
	 * Date of Creation: 14/08/2019
	 * Method name: getAllProductDetails
	 * Parameters: Parameters of type string
	 * Return Value: Object contains all product details
	 *Purpose: To display products who status is equals to placed(PLD) or dispatched(DISP)
	 */

		@Override
		public List<OrderedItem> getAllProductDetails(String ordStatus,String ordst) throws CapStoreException {
			try {
				if((ordStatus.equals("PLD")|| ordst.equals("DISP"))||(ordStatus.equals("DISP")|| ordst.equals("PLD"))) {
					return orderItemRepo.getAllProductDetails(ordStatus,ordst);
				}
				else
					return orderItemRepo.getAllProductDetails(ordStatus,ordst);
			}catch(Exception e) {
				throw new CapStoreException(e.getMessage());
			}
		}

		/***
		 * Author:Vyshnavi Muthumula
		 * Date of Creation: 14/08/2019
		 * Method name: getPlacedProducts
		 * Parameters:Parameters of type string
		 * Return Value: Object contains all product details
		 *Purpose: To display products who status is equals to placed(PLD)
		 */

	@Override
	public List<OrderedItem> getPlacedProducts() throws CapStoreException {
		try {
			
				return orderItemRepo.getPlacedProducts();
			
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}
	/***
	 * Author:Vyshnavi Muthumula
	 * Date of Creation: 14/08/2019
	 * Method name: getPlacedProducts
	 * Parameters:Parameters of type string
	 * Return Value: Object contains all product details
	 *Purpose: To display products who status is equals to dispatched(DISP)
	 */
	@Override
	public List<OrderedItem> getDispatchedProducts() throws CapStoreException {
		try {
			
			return orderItemRepo.getDispatchedProducts();
			
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	/***
	 * Author:Vyshnavi Muthumula
	 * Date of Creation: 14/08/2019
	 * Method name: updatePlacedProducts
	 * Parameters:Parameters of type string
	 * Return Value: Returns Object which contains all product details
	 *Purpose: To update placed products to dispatched products
	 */
	@Override
	public List<OrderedItem> updatePlacedProducts(String ordId, String ordStatus) throws CapStoreException {
		try {
			Optional<OrderedItem> optional=orderItemRepo.findById(ordId);
			if(ordStatus.equalsIgnoreCase("PLD")) {
				OrderedItem placed=optional.get();
				placed.setOrdStatus("DISP");
				orderItemRepo.save(placed);
				return orderItemRepo.getPlacedProducts();
			}
			else {
				throw new CapStoreException("Invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
		
	}

	/***
	 * Author:Vyshnavi Muthumula
	 * Date of Creation: 14/08/2019
	 * Method name: updateDispatchedProducts
	 * Parameters:Parameters of type string
	 * Return Value: Returns Object which contains all product details
	 *Purpose: To update dispatched products to received products
	 */
	
	@Override
	public List<OrderedItem> updateDispatchedProducts(String ordId, String ordStatus) throws CapStoreException {
		try {
			Optional<OrderedItem> optional=orderItemRepo.findById(ordId);
			if(ordStatus.equalsIgnoreCase("DISP")) {
				OrderedItem dispatched=optional.get();
				dispatched.setOrdStatus("REC");
				orderItemRepo.save(dispatched);
				return orderItemRepo.getDispatchedProducts();
			}
			else {
				throw new CapStoreException("Invalid option");
			}
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	/***
	 * Author:Vyshnavi Muthumula
	 * Date of Creation: 14/08/2019
	 * Method name: updatePlacedProducts
	 * Parameters:Parameters of type string
	 * Return Value: Returns Object which contains all product details
	 *Purpose: This method contains all products who status is equals to placed or dispatched. If user click update on placed products it changes to dispatched products and if customer clicks on dispatched products it changes to received products
	 *
	 */
	
	@Override
	public List<OrderedItem> updateProduct(String ordId, String ordStatus,String ordStatus4) throws CapStoreException {
		try {
			Optional<OrderedItem> optional=orderItemRepo.findById(ordId);
			if(ordStatus.equalsIgnoreCase("PLD")) {
				OrderedItem dispatched=optional.get();
				dispatched.setOrdStatus("DISP");
				orderItemRepo.save(dispatched);
				return orderItemRepo.getAllProductDetails(ordStatus,ordStatus4);
			}
			else if(ordStatus.equalsIgnoreCase("DISP")) {
				OrderedItem dispatched=optional.get();
				dispatched.setOrdStatus("REC");
				orderItemRepo.save(dispatched);
				return orderItemRepo.getAllProductDetails(ordStatus,ordStatus4);
			}
			else
				throw new CapStoreException("Product is received");
		}catch(Exception e) {
			throw new CapStoreException(e.getMessage());
		}
	}

	
	
}
