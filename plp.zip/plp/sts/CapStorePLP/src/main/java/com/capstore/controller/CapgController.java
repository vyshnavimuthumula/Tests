package com.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.OrderedItem;
import com.capstore.exception.CapStoreException;
import com.capstore.service.CapgService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CapgController {

	@Autowired CapgService capgService;
	
//	@RequestMapping(value="/add",method=RequestMethod.POST)
//	public List<OrderedItem> addCapStore(@RequestBody OrderedItem products) throws CapStoreException{
//		return capgService.addCapStore(products);
//	}
	
	@RequestMapping("/capstore/{ordStatus}/{ordst}")
	public List<OrderedItem> getAllProductDetails(@PathVariable String ordStatus,@PathVariable String ordst) throws CapStoreException{
		return capgService.getAllProductDetails(ordStatus,ordst);
	}	
	
	
	@RequestMapping(value="/placedproducts")
	public List<OrderedItem> getProducts() throws CapStoreException{
			return capgService.getPlacedProducts();
		}
	
	@RequestMapping(value="/dispatchedproducts")
	public List<OrderedItem> getDispatchedProducts() throws CapStoreException{
		return capgService.getDispatchedProducts();
	}
	
	@RequestMapping(value="/updatePlacedProducts/{ordId}/{ordStatus}")
	public List<OrderedItem> updatePlacedProducts(@PathVariable String ordId,@PathVariable String ordStatus) throws CapStoreException{
		return capgService.updatePlacedProducts(ordId,ordStatus);
	}
	
	@RequestMapping(value="/updateDispatchedProducts/{ordId}/{ordStatus}")
	public List<OrderedItem> updateDispatchedProducts(@PathVariable String ordId,@PathVariable String ordStatus) throws CapStoreException{
		return capgService.updateDispatchedProducts(ordId,ordStatus);
	}
	
	@RequestMapping(value="/updateProduct/{ordId}/{ordStatus}")
	public List<OrderedItem> updateProduct(@PathVariable String ordId,@PathVariable String ordStatus,String ordStatus4) throws CapStoreException{
		return capgService.updateProduct(ordId,ordStatus,ordStatus4);
	}

}
