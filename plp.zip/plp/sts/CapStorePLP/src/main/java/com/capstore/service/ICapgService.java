package com.capstore.service;

import java.util.List;

import com.capstore.bean.OrderedItem;
import com.capstore.exception.CapStoreException;

public interface ICapgService {
	
	public List<OrderedItem> addCapStore(OrderedItem products) throws CapStoreException;
	public List<OrderedItem> getAllProductDetails(String ordStatus,String ordst) throws CapStoreException;
	
	//public List<CapStore> getAllProducts(String ordStatus) throws CapStoreException;
	public List<OrderedItem> getDispatchedProducts() throws CapStoreException;
	public List<OrderedItem> getPlacedProducts() throws CapStoreException;
	public List<OrderedItem> updatePlacedProducts(String ordId,String ordStatus) throws CapStoreException;
	public List<OrderedItem> updateDispatchedProducts(String ordId,String ordStatus) throws CapStoreException;
	
	// previous updating all products public List<CapStore> updateAllProducts(String ordId,String ordStatus) throws CapStoreException;
	public List<OrderedItem> updateProduct(String ordId,String ordStatus,String ordStatus4) throws CapStoreException;
}
