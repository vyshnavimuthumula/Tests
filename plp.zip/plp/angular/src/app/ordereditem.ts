import { Customer } from './customer';
import { Product } from './product';
import { Merchant } from './merchant';


export class OrderedItem {
    ordId:string;
    customer:Customer;
    product:Product;
    merchant:Merchant;
    orderTime:string;
    ordPrice:number;
    shippingAddress:string;
    ordStatus:String;
    ordQty:string;
}