import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule,routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { UpdatingStatusComponent } from './updating-status/updating-status.component';
import { PlacedProductsComponent } from './placed-products/placed-products.component';
import { DispatchedProductsComponent } from './dispatched-products/dispatched-products.component';
import { AllProductsComponent } from './all-products/all-products.component';
import {HttpClientModule} from '@angular/common/http'

@NgModule({
  declarations: [
    AppComponent,
    UpdatingStatusComponent,
    PlacedProductsComponent,
    DispatchedProductsComponent,
    AllProductsComponent,
    routingComponents
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
