export class Customer {
    custId:string;
    emailId:string;
    firstName:string;
    lastName:string;
    isValid:string;
    address:string;
    phoneNo:string;
    walletBalance:number;
   }
   