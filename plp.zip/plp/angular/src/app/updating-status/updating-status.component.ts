import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-updating-status',
  templateUrl: './updating-status.component.html',
  styleUrls: ['./updating-status.component.css']
})
export class UpdatingStatusComponent implements OnInit {
  capstore: any;
  capStoreService: any;

  constructor() { }

  ngOnInit() {
  }

}
