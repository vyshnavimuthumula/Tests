import { Component, OnInit } from '@angular/core';
import { CapStoreService } from '../cap-store.service';
import { OrderedItem } from '../ordereditem';



@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.css']
})
export class AllProductsComponent implements OnInit {
  capstore: OrderedItem[];
  capstore2:OrderedItem[];

  constructor(private capStoreService:CapStoreService) { }

  ngOnInit() {
    this.capStoreService.showAllProducts().subscribe(response=>this.handleSuccessfulResponse(response));
  }
  handleSuccessfulResponse2(response){
    this.capstore2=response;
    console.log(this.capstore2);    
  }

    handleSuccessfulResponse(response){
      this.capstore=response;
      this.capStoreService.getProducts();
    }
updateProduct(productOrdId: string,productOrdStatus: string){
  this.capStoreService.updateProduct(productOrdId,productOrdStatus).subscribe(data => {
    this.capstore = data;
    console.log(this.capstore)
});
}
}
