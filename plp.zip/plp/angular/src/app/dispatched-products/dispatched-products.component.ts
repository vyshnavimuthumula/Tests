import { Component, OnInit, Injectable } from '@angular/core';
import { CapStoreService } from '../cap-store.service';
import { OrderedItem } from '../ordereditem';



@Component({
  selector: 'app-dispatched-products',
  templateUrl: './dispatched-products.component.html',
  styleUrls: ['./dispatched-products.component.css']
})
@Injectable({
  providedIn:"root"
})
export class DispatchedProductsComponent implements OnInit {
  capstore: OrderedItem[];

  constructor(private capStoreService:CapStoreService) { }

  ngOnInit() {
    this.capStoreService.showDispatchedProducts().subscribe(response=>this.handleSuccessfulResponse(response));
    console.log(this.capstore);
  }
  handleSuccessfulResponse(response){
    this.capstore=response;
    console.log(this.capstore);
}
    
  updateDispStatus(productOrdId: string,productOrdStatus: string){
    this.capStoreService.updateDisp(productOrdId,productOrdStatus).subscribe(data => {
      this.capstore = data;
  });
}
}

