package lab10;
public class Exercise2 implements Runnable{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Timer starts");
		for(int i=0;i<50;i++) {
			for(int j=1;j<=10;j++) {
				System.out.println(j);
				try {
					Thread.sleep(1000);
				}catch(Exception e) {
					System.out.println(e);
				}
			}
			try {
				Thread.sleep(10000);
			}catch(Exception e) {
				System.out.println("Timer Restart");
			}
		}
		
	}
public static void main(String args[]) {
	Thread thread = new Thread(new Exercise2());
	thread.start();
}
}