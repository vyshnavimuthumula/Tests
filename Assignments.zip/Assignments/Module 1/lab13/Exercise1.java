package lab13;

import java.util.function.BiFunction;

public class Exercise1 {
	

	static int calcDouble()
	{
		BiFunction<Integer,Integer,Integer> calcPower = (x,y)->(int)(Math.pow(x,y));
		return(calcPower.apply(2, 3));
		
	}
	
	
	public static void main(String args[]) {
	
	
	
	System.out.println(calcDouble());
}
}
