package lab4;
import java.util.*;
public class exercise1 {
	public static void main(String[] args) {
		int n,sum=0,r;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		n = sc.nextInt();
		int num = n;
		while(n>0) {
			r = n%10;
			n = n/10;
			sum=sum+(r*r*r);
		}
		System.out.println("Sum of cobes of the digits of a number " + num + " is " + sum);
	}
}
