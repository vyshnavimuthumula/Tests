package lab3;
import java.util.*;
public class exercise3 {
	public static void main(String[] args) {
		getSorted();		
	}
	public static void getSorted() {
		Scanner sc = new Scanner(System.in);
		int a[]=new int[5];
		for(int i=0;i<5;i++)
			a[i]=sc.nextInt();
		int temp;
		for(int i=0;i<5;i++) {
			if(a[i]>a[i+1]) {
				temp=a[i];
				a[i]=a[i+1];
				a[i+1]=temp;
			}
		}
		for(int i=5;i>0;i++)
			System.out.println("Reverse sored array " + a[i]);
	}
}
