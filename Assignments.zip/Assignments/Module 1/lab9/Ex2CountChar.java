package lab9;
import java.util.*;
public class Ex2CountChar {
public static void main(String args[]) {
	String s;
	Scanner sc =new Scanner(System.in);
	s = sc.next();
	HashMap<String,Integer> c = new HashMap<String,Integer>();
	for(char ch:s.toCharArray()) {
		String str = ch + "";
		if(!c.containsKey(str)) {
			c.put(str,1);
		}else
			c.put(str,c.get(str)+1);
	}
	System.out.println(c);
	sc.close();
}

}
