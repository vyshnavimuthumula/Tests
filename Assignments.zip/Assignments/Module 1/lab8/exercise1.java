package lab8;
import java.util.StringTokenizer;
public class exercise1 {
	public static void main(String args[]) {
		StringTokenizer stn = new StringTokenizer("1 2 3 4 5 6", " ");
		int sum = 0,n;
		while(stn.hasMoreTokens()) {
			n = Integer.parseInt(stn.nextToken());
			System.out.println("Each integer in the line of integers " + n);
			sum = sum + n;
		}
		System.out.println("Sum of integers " + sum);
	}
	

}
