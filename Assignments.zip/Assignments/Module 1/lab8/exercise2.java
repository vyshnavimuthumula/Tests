package lab8;
import java.io.*;
public class exercise2 {
	public static void main(String args[]) throws IOException {
		File file = new File("C:\\Users\\vymuthum\\Desktop\\game.txt");
		BufferedReader b = new BufferedReader(new FileReader(file)); 
	  
		String st;
		int c=0;
		while ((st = b.readLine()) != null) {
			c++;
			System.out.println(c + "." + st); 
		    b.close();
		}
	  } 
}

