package com.cg.eis.pl;
import java.util.ArrayList;

public class DisplayOutput {
    public void showOutput(ArrayList<String> arrayList) {
        for(String str : arrayList) {
            System.out.println(str);
        }
    }
}
