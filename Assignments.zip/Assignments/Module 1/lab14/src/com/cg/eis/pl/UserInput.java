package com.cg.eis.pl;
import java.io.IOException;
import java.util.Scanner;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.Services;
public class UserInput {
    public void readInput() throws IOException {
        int empId;
        String empName;
        int salary;
        String empDesignation;       
        Employee employee = new Employee();        
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        System.out.println("Enter the Employee ID: ");
        empId = sc.nextInt();
        employee.setEmpId(empId);
        
        System.out.println("Enter the Employee Name: ");
        empName = sc1.nextLine();
        employee.setName(empName);
        
        System.out.println("Enter the Employee Salary: ");
        salary = sc.nextInt();
        employee.setSalary(salary);
        
        System.out.println("Enter the Employee Designation: ");
        empDesignation = sc1.nextLine().toLowerCase();
        employee.setDesignation(empDesignation);
        
        sc.close();
        
        
        
        EmployeeService empService = new Services();
        empService.serviceProvide(employee);
    }
}