package com.cg.eis.service;
import java.io.IOException;
import java.util.ArrayList;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.DataStorage;
import com.cg.eis.pl.DisplayOutput;
public class Services implements EmployeeService{
    private String service;
    
    public String getService() {
        return service;
    }
    public void setService(String service) {
        this.service = service;
    }
    public void serviceProvide(Employee emp) {
        
        Services s = new Services();
        if(emp.getInsuranceScheme().equals("Scheme A")) {
            s.setService("Free Shopping");
        }
        else if(emp.getInsuranceScheme().equals("Scheme B")) {
            s.setService("Free Movie Tickets");
        }
        else if(emp.getInsuranceScheme().equals("Scheme C")) {
            s.setService("Only company perks");
        }
        else if(emp.getInsuranceScheme().equals("No Scheme")) {
            s.setService("Sorry... You are not Eligible for any Schemes");
        }
        else
            s.setService("Sorry... You are not Eligible for any Schemes");
        
        DataStorage ds = new DataStorage();
        try {
            ds.storeData(emp, s);
        } catch (IOException e) {
            
            e.printStackTrace();
        }        
    }
    public void move(ArrayList<String> arrayList) {
    DisplayOutput displayOutput = new DisplayOutput();
    displayOutput.showOutput(arrayList);
    }
 

}