package com.capg1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entitymanager = factory.createEntityManager();
		Author1 author = new Author1();
		author.setName("Singh");
		Book book = new Book();
		book.setISBN(152);
		book.setTitle("Surgery Essence");
		book.setPrice(200);
		author.setBook(book);
		entitymanager.getTransaction().begin();
		entitymanager.persist(author);
//		entitymanager.persist(book);
		entitymanager.getTransaction().commit();
	}
}
