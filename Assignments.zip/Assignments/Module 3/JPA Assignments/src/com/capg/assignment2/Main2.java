package com.capg.assignment2;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


public class Main2 {
	public static void main(String args[]) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entitymanager = factory.createEntityManager();
		
		Scanner sc = new Scanner(System.in);
		
		Author2 auth = new Author2();
		System.out.println("Enter Author name");
		auth.setName(sc.nextLine());
		
		Book2 book1 = new Book2();
		System.out.println("Enter Book Title");
		book1.setTitle(sc.nextLine());
		System.out.println("Enter Book Price");
		book1.setPrice(Integer.parseInt(sc.nextLine()));
		
		Book2 book2 = new Book2();
		System.out.println("Enter Book2 Title");
		book2.setTitle(sc.nextLine());
		System.out.println("Enter Book2 Price");
		book2.setPrice(Integer.parseInt(sc.nextLine()));
		
		auth.getBook().add(book1);
		auth.getBook().add(book2);
		
		entitymanager.getTransaction().begin();
		entitymanager.persist(auth);
		entitymanager.getTransaction().commit();
		TypedQuery<Book2> query = entitymanager.createQuery("from Book2",Book2.class);
		List<Book2> b1=query.getResultList();
		for(Book2 booklist:b1) {
			System.out.println(booklist);
		}
		TypedQuery<Book2> query1=entitymanager.createQuery("select book from Author2 a join a.book b where a.name = :aname ", Book2.class);
		List<Book2> b2=query1.getResultList();
		for(Book2 bookslist:b2) {
			System.out.println(bookslist);
		    }
		
//		TypedQuery<Book2> query2=entitymanager.createQuery("from Book2 where price between 500 and 1000 ", Book2.class);
//		List<Book2> b3=query.getResultList();
//		for(Book2 pricelist:b3) {
//			System.out.println(pricelist);
//		    }
		
		sc.close();
	}
	
}
