import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../company.service';
import { Icompany } from '../icompany';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  product:Icompany[];

  constructor(private companyService:CompanyService) { }

  ngOnInit() {
    this.companyService.getCompany().subscribe(data=>this.product=data);
  }
  delete(item){
    this.product.splice(this.product.indexOf(item),1);
    }
}
