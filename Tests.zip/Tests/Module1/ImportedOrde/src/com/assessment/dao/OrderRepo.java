package com.assessment.dao;

import com.assessment.bean.Order;

public interface OrderRepo {
	
	public void saveOrder(Order bean);

}
