package com.assessment.service;

import com.assessment.bean.Order;

public interface OrderService {
	
	public int calculateOrder(Order bean);

}
