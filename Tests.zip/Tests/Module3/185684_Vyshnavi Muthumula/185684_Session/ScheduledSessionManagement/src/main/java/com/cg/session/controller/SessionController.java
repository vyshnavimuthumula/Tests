package com.cg.session.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.session.bean.Session;
import com.cg.session.exception.SessionException;
import com.cg.session.service.ISessionService;

@RestController
public class SessionController {

	@Autowired
	ISessionService sessionService;
	
	
	/*
	Author : Vyshnavi Muthumula
	Date of Duration : 30/1/2019
	Method Name : viewAllSessions
	Return value : Returns session details and if there is any exception it prints that exception
	Purpose : by passing url=ViewAllSession we get all session details
	*/
	
	@RequestMapping("/ViewAllSession")
	public List<Session> viewAllSessions() throws SessionException{
		return sessionService.viewAllSessions();
	}
	
	/*
	Author : Vyshnavi Muthumula
	Date of Duration : 30/1/2019
	Method Name : viewAllSessions
	Return value : Returns session details and if there is any exception it prints that exception
	Purpose : by passing url=CreateSession we are creating session details
	*/
	
	@RequestMapping(value="/CreateSession", method=RequestMethod.POST)
	public List<Session> createSession(@RequestBody Session session) throws SessionException{
		return sessionService.createSession(session);
	}
	
	/*
	Author : Vyshnavi Muthumula
	Date of Duration : 30/1/2019
	Method Name : updateDuration
	Return value : Returns session details and if there is any exception it prints that exception
	Purpose : by passing url=UpdateSession/{id} we are updating only faculty and mode using  id as path variable
	*/
	
	@RequestMapping(value="/UpdateSession/{id}",method=RequestMethod.PUT)
	public List<Session> updateDuration(@PathVariable Integer id,@RequestBody Session session) throws SessionException{
		return sessionService.updateSession(id, session);
	}
	/*
	Author : Vyshnavi Muthumula
	Date of Duration : 30/1/2019
	Method Name : DeleteSession
	Return value : Returns session details and if there is any exception it prints that exception
	Purpose : by passing url=/DeleteSession/{id} we are deleting the session details using  id as path variable
	*/
	@RequestMapping(value="/DeleteSession/{id}",method=RequestMethod.DELETE)
	public List<Session> deleteSession(@PathVariable int id) throws SessionException{
		sessionService.deleteSession(id);
		return sessionService.viewAllSessions();
}
}
