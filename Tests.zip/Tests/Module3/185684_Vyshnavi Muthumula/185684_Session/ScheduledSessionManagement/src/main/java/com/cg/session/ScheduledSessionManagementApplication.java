package com.cg.session;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScheduledSessionManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScheduledSessionManagementApplication.class, args);
	}

}
